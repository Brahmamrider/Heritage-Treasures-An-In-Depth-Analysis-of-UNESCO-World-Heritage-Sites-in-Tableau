Contains Assignments in PDF format
